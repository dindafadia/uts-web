<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        return view('wp');
    }
    public function praktikum()
    {
        return view('prak');
    }
    public function pr()
    {
        return view('pr');
    }

}
